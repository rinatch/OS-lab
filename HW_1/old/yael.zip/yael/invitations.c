
#include <linux/sched.h>
#include <asm/current.h>
#include <asm/uaccess.h>
#include <linux/module.h>  /* Needed by all modules */
#include <linux/kernel.h>  /* Needed for KERN_ALERT */

#include <linux/procenet_structs.h>
#include <linux/errno.h>
#include <linux/slab.h>


ssize_t sys_procenet_invitations(struct invitation_t *invitations, ssize_t size) {
    printk(KERN_ERR "got into invitations!!\n");

   /* //get len of processes invitations list//todo add to task_struct
    int len = 0;
    struct invitations_list_node* curr_inv_list;
    list_t* invitation_it;
    list_for_each(invitation_it, &current->invitations)
    {
        curr_inv_list = list_entry(invitation_it, struct invitations_list_node, ptr);
        if (curr_inv_list != NULL) {
            len++;
        }
    }

    if (size < 0) {
        printk(KERN_ERR "EINVAL\n");
        return -EINVAL;
    } else if (size == 0 || invitations == NULL) {
        printk(KERN_ERR "size == 0 || invitations == NULL. len = %d\n", (int)len);
        return (ssize_t)len;
    }
    // If we get here there are invitations to add to the buffer
    invitations = kmalloc((int)size * sizeof(struct invitation_t), GFP_KERNEL);
    if(!invitations){
        printk(KERN_ERR "ENOMEM\n");
        return -ENOMEM;
    }

    //run on invitations list and copy to the array
    struct invitations_list_node *new_inv_node;
    list_t* invitations_it;
    int i = 0;
    list_for_each(invitations_it, &current->invitations)
    {
        if (len > 0) {//there are more invitations to copy
            new_inv_node = list_entry(invitations_it,struct invitations_list_node, ptr);
            invitations[i].pid = new_inv_node->inv_data.pid;
            if (strcpy(invitations[i].message , new_inv_node->inv_data.message ) == NULL){
                return -EFAULT;
            }
            len--;
        } else {
            invitations[i].pid = 0;
            if (strcpy(invitations[i].message , "" ) == NULL){
                return -EFAULT;
            }
        }
        i++;
    }

    return (ssize_t)len;*/
    return 0;
}
