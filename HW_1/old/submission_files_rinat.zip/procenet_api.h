#ifndef _PROCENET_API_H
#define _PROCENET_API_H

#include <errno.h>

int procenet_invite(pid_t pid, char *message)
{
    printf("we are here 1\n");
    int res;
    __asm__
            (
            "pushl %%eax;"
            "pushl %%ebx;"
            "pushl %%ecx;"
            "movl $243, %%eax;"
            "movl %1, %%ebx;"
            "movl %2, %%ecx;"
            "int $0x80;"
            "movl %%eax, %0;"
            "popl %%ecx;"
            "popl %%ebx;"
            "popl %%eax;"
            :"=m" (res)
            : "m" (pid) ,"m" (message)
            );
    printf("we are here 2\n");
    if (res >= (unsigned long)(-125))
    {
        errno = -res;
        res = -1;
    }
    return (int)res;
}

int procenet_respond(pid_t pid, int response)
{
    int res;
    __asm__
            (
            "pushl %%eax;"
            "pushl %%ebx;"
            "pushl %%ecx;"
            "movl $244, %%eax;"
            "movl %1, %%ebx;"
            "movl %2, %%ecx;"
            "int $0x80;"
            "movl %%eax, %0;"
            "popl %%ecx;"
            "popl %%ebx;"
            "popl %%eax;"
            :"=m" (res)
            : "m" (pid) ,"m" (response)
            );
    if (res >= (unsigned long)(-125))
    {
        errno = -res;
        res = -1;
    }
    return (int)res;
}
#endif //INVITE_C_PROCENET_API_H

