

#ifndef _PROCENET_API_H
#define _PROCENET_API_H
#define MAX_FRIENDS 32
#define MAX_MESSAGE 128



struct friend_t{
    pid_t pid;
    int alive;
};

struct invitation_t{
    pid_t pid;
    char  message[MAX_MESSAGE];
    list_t ptr;
};q






#endif //MAIN_C_PROCENET_API_H
